<?php
$db_host = "localhost";
$db_user = "root";
$db_pwd = "123456";
$db_name = "cx";
$db_port = "3306";
$mysql_tag = "tgs_";
?>