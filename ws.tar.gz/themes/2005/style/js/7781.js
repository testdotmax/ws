﻿var online=new Array();
document.write("<script language=\"javascript\" src=\"http://webpresence.qq.com/getonline?Type=1&84486101:\" charset=\"utf-8\" type=\"text/javascript\"></script>");
document.write("<script language=\"javascript\" src=\"http://code2.54kefu.net/kefu/url.js\" charset=\"utf-8\" type=\"text/javascript\"></script>");
document.write("<script language=\"javascript\" src=\"http://code2.54kefu.net/kefu/js/181/7781_code.js\" charset=\"utf-8\" type=\"text/javascript\"></script>");
