<?php
$_LANG['page']['is_true']      = '是';
$_LANG['page']['is_false']     = '否';
$_LANG['page']['fenye_title1'] = '显示从';
$_LANG['page']['fenye_title2'] = '至';
$_LANG['page']['fenye_title3'] = '<<上一页';
$_LANG['page']['fenye_title4'] = '下一页>>';
$_LANG['page']['fenye_title5'] = '条记录';
$_LANG['page']['fenye_title6'] = "总记录";
$_LANG['page']['fenye_title7'] ="总页数";

$_LANG["page"]["_you_upload_pic_type_"]               = "您上传的图片格式有误";
$_LANG['page']['_you_upload_pic_larger_than_300k_']   = "您上传的图片超过300K";
$_LANG['page']['_Copy_file_failed_']                  = "图片上传复制失败";
?>