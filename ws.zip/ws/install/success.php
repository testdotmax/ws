
<HTML>
<HEAD>
<TITLE>微应用网络安装向导-微营销代理查询+防伪系统</TITLE>
<meta name="keywords"       content="微应用网络安装向导"    >
<META  name="description"   content="微应用网络安装向导" >
<META content="MSHTML 6.00.2800.1170" name=GENERATOR>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
body,td{
        word-break:break-all;
        color:#000000;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-size: 12px;
        line-height:18px
}

a:link{color:#333333;
	text-decoration: underline;
}
a:visited {color:#333333;
	text-decoration: underline;
}
a:hover {color:#333333;
	 text-decoration:none;
}

.button{
border-top-width:1;
border-bottom-width:1;
border-left-width:1;
border-right-width:1;
border-style:solid;
border-color:#98A9CF;
height:22;
background-color: #ffffff;
cursor:hand
}
.tdbg{
	background-color:#666666;
        color:#ffffff;
     }  

</style>
</HEAD>



<table  border="0" cellpadding="0" cellspacing="0" width="100%" align=center>
  <tr>
   <td height=50  bgcolor=#0066CC><img src="instyle/img/logo.gif" width=300 height=50></td>
  </tr>
 <tr>
   <td height=20 bgcolor=#0066CC><td>
 </tr>
</table>


<table border=0 cellpadding=0 cellspacing=0 width=100%>
 <tr>
   <td height=20  bgcolor="#98A9CF" align=center>恭喜您程序安装成功<td>
 </tr>
</table>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
 <tr><td align=center>
<br>
<br>
<br>
恭喜您！程序安装成功！<br>
为了您的程序安全，请安装成功后删除install目录！<br>

后台地址 域名/admin  默认用户名 admin 密码 admin   <a href="../admin/">点此登录后台</a>  <br>
请登录后及时修改您的密码！</td>
</tr>

<tr>
<td colspan=2 align=center height=40px>


</td>
</tr>
</table>














<div align=left style="padding-left:100px"><span id="Lbl_error" style="color:#ff0000;font-size:13px"></span></div>
<table border=0 cellpadding=0 cellspacing=0 width=100%>
  <tr>
   <td height=20 background="instyle/images/img/bg_1.gif" align="center"></td>
 </tr>

</table>

</body>
</html>